package com.cg.RailwayReservationSystem_158000;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface IReservationService extends MongoRepository<Reservation,Long> {
	
	public Reservation findByPnrno(String pnrno);

}
