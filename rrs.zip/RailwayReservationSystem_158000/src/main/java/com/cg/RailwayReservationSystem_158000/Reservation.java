package com.cg.RailwayReservationSystem_158000;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="Reservation")
public class Reservation {
	@Id
	public String pnrno;
	public String passenger_name;
	public String source_loc;
	public String desc_loc;
	public Integer price;
	public Reservation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getPnrno() {
		return pnrno;
	}
	public void setPnrno(String pnrno) {
		this.pnrno = pnrno;
	}
	public String getPassenger_name() {
		return passenger_name;
	}
	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}
	public String getSource_loc() {
		return source_loc;
	}
	public void setSource_loc(String source_loc) {
		this.source_loc = source_loc;
	}
	public String getDesc_loc() {
		return desc_loc;
	}
	public void setDesc_loc(String desc_loc) {
		this.desc_loc = desc_loc;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
	
	

}
