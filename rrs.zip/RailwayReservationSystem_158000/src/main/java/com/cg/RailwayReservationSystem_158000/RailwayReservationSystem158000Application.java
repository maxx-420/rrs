package com.cg.RailwayReservationSystem_158000;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayReservationSystem158000Application {

	public static void main(String[] args) {
		SpringApplication.run(RailwayReservationSystem158000Application.class, args);
	}
}
