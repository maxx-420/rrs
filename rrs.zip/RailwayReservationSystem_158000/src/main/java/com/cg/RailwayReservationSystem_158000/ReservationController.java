package com.cg.RailwayReservationSystem_158000;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping(value="/rrs")
public class ReservationController {
	
	@Autowired
	IReservationService idao;
	
	@GetMapping(path="/user/{pnrno}",produces=MediaType.APPLICATION_JSON_VALUE)
	public Reservation getDetails(@PathVariable("pnrno") String pnrno){
	  Reservation res = idao.findByPnrno(pnrno);
	  if(res==null){
		  throw new NotFoundException("PNR not Found wrong PNR no :"+ pnrno);
	  }
	  return res;
	}
	
	@PostMapping(path="/insert",consumes=MediaType.APPLICATION_JSON_VALUE)
	public List<Reservation> getByPrice(@RequestBody List<Reservation> reservation){
		return idao.saveAll(reservation);
		
	}
	

}
